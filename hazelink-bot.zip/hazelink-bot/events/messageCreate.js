// ============================================================
//  events/messageCreate.js — Prefix command handler
// ============================================================

const logger = require("../utils/logger");

module.exports = {
  once: false,

  /**
   * @param {import('discord.js').Message} message
   * @param {import('discord.js').Client} client
   */
  async execute(message, client) {
    // Ignore bots & DMs
    if (message.author.bot || !message.guild) return;

    const prefix = client.config.prefix ?? "!";

    // Check for prefix
    if (!message.content.startsWith(prefix)) return;

    const args    = message.content.slice(prefix.length).trim().split(/\s+/);
    const cmdName = args.shift().toLowerCase();

    const command = client.prefixCommands.get(cmdName);
    if (!command) return;

    // Cooldown check
    const { cooldowns } = client;
    if (!cooldowns.has(`prefix_${command.name}`)) {
      const { Collection } = require("discord.js");
      cooldowns.set(`prefix_${command.name}`, new Collection());
    }
    const now       = Date.now();
    const timestamps = cooldowns.get(`prefix_${command.name}`);
    const cooldownMs = (command.cooldown ?? 3) * 1000;

    if (timestamps.has(message.author.id)) {
      const expiresAt = timestamps.get(message.author.id) + cooldownMs;
      if (now < expiresAt) {
        const remaining = ((expiresAt - now) / 1000).toFixed(1);
        return message.reply(`⏳ Please wait **${remaining}s** before using \`${prefix}${command.name}\` again.`);
      }
    }
    timestamps.set(message.author.id, now);
    setTimeout(() => timestamps.delete(message.author.id), cooldownMs);

    try {
      await command.run(message, args, client);
    } catch (err) {
      logger.error(`[messageCreate] Error running ${cmdName}: ${err.message}`);
      message.reply("❌ An error occurred while running that command.").catch(() => null);
    }
  },
};
